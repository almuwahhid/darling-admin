<div class="dashboard-ecommerce" style="min-height: 565px;">
  <div class="container-fluid dashboard-content centerVertical">
    <!-- ============================================================== -->
    <!-- pageheader  -->
    <!-- ============================================================== -->
    <div class="row">
      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
          <span class="lead">Selamat Datang di halaman Admin</span>
      </div>
    </div>
  </div>
</div>
